<?php
/**
 * Created by PhpStorm.
 * User: air
 * Date: 12.06.18
 * Time: 21:12
 */
$lang['title'] = 'Hello there! We are';
$lang['param'] = 'coming soon.';
$lang['email'] = 'info@codebe.agency';