<?php
/**
 * Created by PhpStorm.
 * User: air
 * Date: 12.06.18
 * Time: 21:12
 */
$lang['title'] = 'Привет!Мы здесь!';
$lang['param'] = 'скоро вернемся.';
$lang['email'] = 'info@codebe.agency';
// и тд.